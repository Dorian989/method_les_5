import scrapy


class BookSpider(scrapy.Spider):
    name = 'book'
    allowed_domains = ['book24.ru']
    start_urls = ['http://book24.ru/']

    pages_count = 12

    def start_requests(self):
        for page in range(1, 1 + self.pages_count):
            url = f'https://book24.ru/search/page-{page}/?q=%D1%81%D1%82%D0%B8%D0%B2%D0%B5%D0%BD+%D0%BA%D0%B8%D0%BD%D0%B3'
            yield scrapy.Request(url, callback=self.parse_pages)

    def parse_pages(self, response, **kwargs):
        for href in response.css('a.book-preview__title-link attr::("href")').extract():
            url = response.urljoin(href)
            yield scrapy.Request(url, callback=self.parse())

    def parse(self, response, **kwargs):
        techs = {}
        for row in response.css('div.item-detail__first-box'):
            cols = row.css('div.item-detail__informations-box::text').extract(),
            techs[cols[0]] = cols[1]

        item = {
            'url': response.request.url,
            'title': response.css('book-preview__title-link::text').extract_first('').strip(),
            'price': response.css('book-preview__price-current::text').extract_first('').strip,
            'price_discont': response.css('book-preview__price-old-value::text').extract_first('').strip(),
            'techs': techs
        }
        yield item