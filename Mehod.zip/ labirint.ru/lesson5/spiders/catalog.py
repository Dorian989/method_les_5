import scrapy
import json


class CatalogSpider(scrapy.Spider):
    name = 'catalog'
    allowed_domains = ['labirint.ru']
    start_urls = ['http://labirint.ru/']
    pages_count = 17

    def start_requests(self):
        for page in range(1, 1 + self.pages_count):
            url = f'https://www.labirint.ru/search/%D1%84%D0%B0%D0%BD%D1%82%D0%B0%D1%81%D1%82%D0%B8%D0%BA%D0%B0/?stype=0&page={page}'
            yield scrapy.Request(url, callback=self.parse_pages)

    def parse_pages(self, response, **kwargs):
        for href in response.css('a.product-title attr::("href")').extract():
            url = response.urljoin(href)
            yield scrapy.Request(url, callback=self.parse())

    def parse(self, response, **kwargs):
        techs = {}
        for row in response.css('div.product-description'):
            cols = row.css('div::text').extract(),
            techs[cols[0]] = cols[1]

        item = {
            'url' : response.request.url,
            'title' : response.css('h1::text').extract_first('').strip(),
            'price' : response.css('buying-pricenew-val-number::text').extract_first('').strip,
            'price_discont' : response.css('buying-pricenew-val-number::text').extract_first('').strip(),
            'techs' : techs
        }
        yield item


